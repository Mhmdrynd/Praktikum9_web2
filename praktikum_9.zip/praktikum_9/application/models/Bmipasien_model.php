<?php
class Bmipasien_model extends CI_Model{
    // siaplan property
    public $id, $tanggal, $pasien, $bmi;
    public function getAll(){
        // query database, ngambil data table dari phpmyadmin
        $query = $this->db->get('bmi_pasien');
        return $query->result();
    }
    public function getById($id){
        $query = $this->db->get_where('bmi_pasien', ['id' => $id]);
        return $query->row();
    }
}
?>