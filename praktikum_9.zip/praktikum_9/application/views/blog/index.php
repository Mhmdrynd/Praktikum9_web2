<div id="page-content-wrapper">
	<h2>Halaman Blog</h2>
	<h3>Tutorial CodeIgniter 3</h3>
	<p>
	  CodeIgniter adalah Framework PHP.
	</p>
</div>